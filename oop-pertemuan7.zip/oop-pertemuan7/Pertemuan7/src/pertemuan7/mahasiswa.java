/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pertemuan7;

/**
 *
 * @author made
 */
public class mahasiswa {
    private String NIM,NAMA;
    
    public void database(){
        System.out.println ("Saya Sudah Menyerah");
        
}
    public void datamhs(String nnim){
        this.NIM=nnim;
        System.out.printf("Saya Sudah Menyerah %s\n",this.NIM);
    }
    public void datamhs(String nnim, String nnama){
        this.NIM=nnim;
        this.NAMA=nnama;
        System.out.printf ("Data Mahasiswa dengan NIM %$ adalah %s\n",this.NIM,this.NAMA);
    }

    void datamhs() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
