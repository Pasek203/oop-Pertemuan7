/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pertemuan702;

import java.util.Scanner;

/**
 *
 * @author made
 */
public class Pertemuan702 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       String ulang="ya";
       String pil="1";
       
       Scanner p = new Scanner(System.in);
       
       do{
           System.out.println("Aplikasi android");
           System.out.println("1. Hitung Luas Persegi");
           System.out.println("2. Hitung Luas Segitiga");
           System.out.println("3. Selesai ");
           System.out.println("pilih (1/2/3): ");
           pil = p.nextLine();
           switch (pil) {
            case "1":
                System.out.println("Memilih Menu Hitung Persegi");
           break;
           case "2":
                System.out.println("Memilih Menu Hitung Segitiga");
           break;
           case "3":
               ulang = "tidak";
           break;
               default:
                   System.out.println("Silakan Pilih 1/2/3");
           }
           
       }while(ulang.equals("ya"));
       System.out.println("See you");
    }
    
}
